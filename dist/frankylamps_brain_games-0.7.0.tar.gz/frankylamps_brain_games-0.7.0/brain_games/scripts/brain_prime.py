import brain_games.games.prime


def main():
    brain_games.games.prime.main()


if __name__ == '__main__':
    main()
