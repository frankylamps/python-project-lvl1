import brain_games.games.progression


def main():
    brain_games.games.progression.main()


if __name__ == '__main__':
    main()
