import brain_games.games.gcd


def main():
    brain_games.games.gcd.main()


if __name__ == '__main__':
    main()
