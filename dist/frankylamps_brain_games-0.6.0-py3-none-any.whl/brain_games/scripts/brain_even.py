import brain_games.games.even


def main():
    brain_games.games.even.main()


if __name__ == '__main__':
    main()
